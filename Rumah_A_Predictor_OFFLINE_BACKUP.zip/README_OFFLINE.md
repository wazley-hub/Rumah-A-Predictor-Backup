# Rumah A Predictor - Offline Backup Kit

Cara guna:

1. Install Python.
2. Install Streamlit:
   pip install streamlit pandas numpy openpyxl

3. Double click:
   run_app.bat

Atau:
   streamlit run app.py

Fail ini bertujuan sebagai backup penuh sekiranya GitHub, Streamlit Cloud atau APK menghadapi masalah.
