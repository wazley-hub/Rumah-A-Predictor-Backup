# Rumah A Predictor - Offline Backup Kit V2

## Masalah biasa

Jika keluar mesej:

`Python was not found`

maksudnya Python belum dipasang atau belum masuk PATH.

## Cara install Python

1. Pergi ke laman Python.
2. Download Python 3.11 atau 3.12.
3. Semasa install, pastikan tick:

`Add Python to PATH`

4. Siapkan installation.
5. Restart komputer.
6. Double click `run_app.bat`.

## Cara guna selepas Python siap

Double click:

`run_app.bat`

Fail ini akan cuba install package yang diperlukan:

- streamlit
- pandas
- numpy
- openpyxl
- requests

Kemudian app akan dibuka di browser secara local.
