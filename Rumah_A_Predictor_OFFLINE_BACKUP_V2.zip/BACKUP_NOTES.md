Backup ini mengandungi:
- app.py
- TotoHistoryAll.xlsx
- README
- Run launcher

Simpan salinan di:
- PC utama
- External HDD/USB
- Google Drive/OneDrive
- GitHub repository
