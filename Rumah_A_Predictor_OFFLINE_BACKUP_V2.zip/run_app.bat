@echo off
title Rumah A Predictor Offline
cd /d "%~dp0"

echo ==========================================
echo   Rumah A Predictor - Offline Launcher
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    echo Python launcher dijumpai.
    echo Semak / install package diperlukan...
    py -m pip install streamlit pandas numpy openpyxl requests
    echo.
    echo Membuka Rumah A Predictor...
    py -m streamlit run app.py
    pause
    exit /b
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo Python dijumpai.
    echo Semak / install package diperlukan...
    python -m pip install streamlit pandas numpy openpyxl requests
    echo.
    echo Membuka Rumah A Predictor...
    python -m streamlit run app.py
    pause
    exit /b
)

echo Python tidak dijumpai dalam komputer ini.
echo.
echo Sila install Python dahulu:
echo 1. Buka https://www.python.org/downloads/
echo 2. Download Python 3.11 atau 3.12
echo 3. Semasa install, TICK "Add Python to PATH"
echo 4. Lepas siap install, restart komputer
echo 5. Cuba double click run_app.bat semula
echo.
pause
